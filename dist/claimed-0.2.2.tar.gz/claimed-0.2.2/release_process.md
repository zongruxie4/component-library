This project currently doesn't follow a strict and regular release cadence. The following rules should be followed:

1. Minor releases HAVE to be created for security fixes and major fixes 
2. Minor releases CAN be created for minor fixes 
3. Major releases HAVE to be created for breaking changes (code using the library has to be changed to continue to work)
